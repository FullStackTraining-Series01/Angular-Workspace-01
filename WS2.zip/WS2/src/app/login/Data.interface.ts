export interface Data{
    name: string;
}

export interface MyData{
    name: string;
}