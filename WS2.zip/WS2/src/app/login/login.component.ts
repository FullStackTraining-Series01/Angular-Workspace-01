import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyData } from './Data.interface';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = "";
  fromChild= "";
  items = ['item1', 'item2'];

  constructor(private router: Router, private loginService: LoginService) { 


  }

  ngOnInit(): void {
    console.log("WHole HTML loaded");
  
  }

  

  goto(){
    this.router.navigate(['/register']);

  
  }

  getUsername(){
  
    this.loginService.getUserName().subscribe(data => {

      console.log( JSON.stringify(data));
     
      this.user = data.name;

    });
  }

  postUsername(){
  
    var mydata :MyData = {name: "Ajay Trainer"};

    this.loginService.postUserName(mydata).subscribe(data => {

      console.log( JSON.stringify(data));
     
      this.user = data.name;

    });
  }

  gotData(event:any){
    console.log(event);

    this.fromChild = event;
  }

}
