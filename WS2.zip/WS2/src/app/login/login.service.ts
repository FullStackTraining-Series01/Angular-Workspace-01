import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Data } from '@angular/router';
import { Observable } from 'rxjs';
import { backend } from 'src/environments/environment';
import { MyData } from './Data.interface';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  url = backend.backendUrl; //"http://localhost:8080/user/name";



  getUserName():Observable<MyData>{
    return this.http.get<MyData>(this.url+"/user/name");
  }

  postUserName(myuser: MyData):Observable<MyData>{
    return this.http.post<MyData>(this.url+"/user/name", myuser);
  }

}
