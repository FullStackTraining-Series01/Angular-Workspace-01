export const environment = {
  production: true
};
export const backend = {
  backendUrl : "http://localhost:8081"
};
